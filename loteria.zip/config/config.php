<?php
    define("FIRST_CONTROLLER", "Cards");
    define("FIRST_ACTION", "index");
?>